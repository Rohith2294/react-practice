import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import image from './backgroundImage.jpg'

const Login = () => {
    // React Router navigation
    const navigate = useNavigate()

    // State for login form values
    const [Formvalues, setFormvalues] = useState()

    // State for signup form values
    const [SignupFormvalues, setSignupFormvalues] = useState()

    // State to handle password visibility toggle
    const [iconchange, seticonchange] = useState('showIcon1')

    // State to switch between Login and SignUp forms
    const [switchForm, setSwitchForms] = useState('Login')

    // State to store API errors
    const [errors, seterrors] = useState([])

    // Function to clear errors after a certain time
    const getError = () => {
        setTimeout(() => {
            seterrors(...errors, '')
        }, 2000);
    }

    // Function to handle login form submission
    const handleSubmit = async (event) => {
        event.preventDefault()

        // Validation for empty email or password
        if (Formvalues === undefined) {
            seterrors({ ...errors, message: 'Please Enter Email Or Password' })
            getError()
        } else if (!Formvalues.email) {
            seterrors({ ...errors, email: 'Please Enter Email' })
            getError()
        } else if (!Formvalues.password) {
            seterrors({ ...errors, password: 'Please Enter password' })
            getError()
        } else {
            // API call for login
            navigate("/Dashboard")
        }
    }

    // Function to handle signup form submission
    const handleSignupSubmitww = async (event) => {
        event.preventDefault()
        console.log(SignupFormvalues,"SignupFormvalues")
        // Validation for empty email or password
        const emailpattend='[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$'
        if (SignupFormvalues === undefined) {
            seterrors({ ...errors, message: 'Invalid Entry' })
            getError()
        } else if (!SignupFormvalues.name) {
            seterrors({ ...errors, name: 'Please Enter name' })
            getError()
        } else if (!SignupFormvalues.email ) {
            seterrors({ ...errors, email: 'Please Enter email' })
            getError()
        } else if (!SignupFormvalues.password) {
            seterrors({ ...errors, password: 'Please Enter password' })
            getError()
        } else {

            // // API call for signup
            // const { name, email, password } = SignupFormvalues
            // const response = await fetch(`http://localhost:5300/api/authintication/createuser`, {
            //     method: "POST",
            //     headers: {
            //         "Content-Type": "application/json"
            //     },
            //     body: JSON.stringify({ name, email, password }),
            // });
            // const json = await response.json();
            // if (json.success === true) {
            //     // Save auth token
            //     localStorage.setItem('token', json.authtoken)
            //     alert("Account Created Successfully", "success");
            // } else {
            //     const errors = json.error
            //     alert(errors)
            // }
        }
    }

    // Function to handle input changes in login form
    const onchange = (e) => {
        setFormvalues({ ...Formvalues, [e.target.name]: e.target.value })
    }

    // Function to handle input changes in signup form
    const SignUponchange = (e) => {
        setSignupFormvalues({ ...SignupFormvalues, [e.target.name]: e.target.value })
    }
    return (
        <div className='container-fluid' style={{
            width: "100%",
            height: "1000px",
            backgroundSize: 'cover',
            backgroundRepeat: 'no-repeat',
            backgroundImage: `url(${(image) || "../public/book.png"})`
        }} >
            <div className='row' style={{ display: 'flex', justifyContent: 'center' }}>
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '90vh', }}>
                    {switchForm === 'Login' &&
                        <div style={{ backgroundColor: 'whiteSmoke', padding: '30px', borderRadius: '20px', lineHeight: '20px', width: '300px' }}>
                            <h4 style={{ textAlign: 'center' }}>Login Page</h4>
                            <p >Login</p>
                            {errors.message && <span className='text-danger'>{errors.message}</span>}

                            <form>
                                <label className='form-label'>Email</label>
                                <input className='form-control' placeholder='Please Enter Email' name='email' onChange={onchange} type='email' required />
                                {errors.email && <span className='text-danger'>{errors.email}</span>}<br />
                                <label className=''>Password</label>
                                <div className="form-group inner-addon right-addon">
                                    <div className="input-group col-6 mx-auto">
                                        <input type={iconchange === 'showIcon1' ? 'password' : 'text'} name='password' onChange={onchange} className="form-control pwd-control" placeholder="Password" required />
                                        <div>{iconchange === 'showIcon1' &&
                                            <i alt="show" className="far fa-eye eye-show"
                                                onClick={() => seticonchange('showIcon2')}
                                            ></i>}
                                            {iconchange === 'showIcon2' &&
                                                <i alt="hide" className="far fa-eye-slash eye-hide"
                                                    onClick={() => seticonchange('showIcon1')}
                                                ></i>
                                            }
                                        </div>
                                    </div>
                                </div>
                                {errors.password && <span className='text-danger'>{errors.password}</span>}
                                <button className='btn btn22 mt-3' onClick={handleSubmit}  >Login</button><br />
                                <span style={{ fontSize: '14px', fontWeight: 'bold' }}>Dont't have an account?<a onClick={() => setSwitchForms('SignUp')}>Signup</a></span>
                            </form>
                            <form >
                            </form>
                        </div>
                    }
                    {switchForm === 'SignUp' &&
                        <div style={{ backgroundColor: 'whiteSmoke', padding: '30px', borderRadius: '20px', lineHeight: '20px', width: '500px' }}>
                            <h4 style={{ textAlign: 'center' }}>SignUp Page</h4>
                            {errors.message && <span className='text-danger'>{errors.message}</span>}

                            <form className='needs-validation'>
                                <label >First Name</label>
                                <input className='form-control' placeholder='Please Enter First Name' name='name' onChange={SignUponchange} type='text' required />
                                {errors.name && <span className='text-danger'>{errors.name}</span>}<br />

                                <label >Email</label>
                                <input className='form-control' placeholder='Please Enter Email' name='email' onChange={SignUponchange} type='email' required />
                                {errors.email && <span className='text-danger'>{errors.email}</span>}<br />

                                <label >Password</label>
                                <div className="form-group inner-addon right-addon">
                                    <div className="input-group col-6 mx-auto">
                                        <input type={iconchange === 'showIcon1' ? 'password' : 'text'} name='password' onChange={SignUponchange} className="form-control pwd-control" placeholder="Password" required />
                                        <div>{iconchange === 'showIcon1' &&
                                            <i alt="show" className="far fa-eye eye-show"
                                                onClick={() => seticonchange('showIcon2')}
                                            ></i>}
                                            {iconchange === 'showIcon2' &&
                                                <i alt="hide" className="far fa-eye-slash eye-hide"
                                                    onClick={() => seticonchange('showIcon1')}
                                                ></i>
                                            }
                                        </div>
                                    </div>
                                </div>
                                {errors.password && <span className='text-danger'>{errors.password}</span>}

                                <div className='row mt-3'>
                                    <div className='col-md-6'>
                                        <button onClick={() => setSwitchForms('Login')} className='btn btn' type='submit'>Login</button>

                                    </div>
                                    <div className='col-md-6'>
                                        <input onClick={handleSignupSubmitww} className='btn btn' type='submit' />
                                    </div>
                                </div>
                            </form>
                        </div>
                    }
                </div>
            </div>
        </div>
    )
}

export default Login
