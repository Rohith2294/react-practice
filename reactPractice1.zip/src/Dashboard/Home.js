import React, { useEffect, useState } from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

const Home = (args) => {
  // State variables
  const [viewToggle, setToggle] = useState('AllDetails'); // Toggle between AllDetails and viewDetails
  const [clickedData, setClickedData] = useState(''); // Data clicked for details
  const [modal, setModal] = useState(false); // Modal state for creating notes
  const [allnotes, setAllNotes] = useState([]); // All notes
  const [createnoteform, setCreateNoteObject] = useState({}); // Form for creating notes

  // Toggle modal
  const toggle = () => setModal(!modal);
  // Function For Switch And ViewDetails
  const handleData = (e) => {
    console.log(e, "handleData")
    setToggle('viewDetails')
    setClickedData(e)
  }
  // Fetch all notes on component mount
  useEffect(() => {
    fetch(`http://localhost:5300/api/notes/fetchallnotes`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "auth-token": localStorage.getItem('token')
      },
    })
      .then(response => response.json())
      .then(json => {
        setAllNotes(json);
      })
      .catch(error => {
        console.error("Error fetching data:", error);
      });

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Handle form submission for creating notes
  const handleCreateNoteSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch(`http://localhost:5300/api/notes/addnote`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "auth-token": localStorage.getItem('token')
      },
      body: JSON.stringify({
        title: createnoteform.title,
        description: createnoteform.description,
        tag: createnoteform.tag
      }),
    });
    const note = await response.json();
    console.log(note, "note");
  };

  // Update create note form fields
  const onChange = (e) => {
    setCreateNoteObject({ ...createnoteform, [e.target.name]: e.target.value });
  };

  return (
    <div className='container-fluid'>
      {/* Button to toggle create note modal */}
      <div>
        <Button color="danger" onClick={toggle}>
          Create Note
        </Button>
        {/* Create note modal */}
        <Modal isOpen={modal} toggle={toggle} {...args}>
          <ModalHeader toggle={toggle}>Modal title</ModalHeader>
          <form>
            <ModalBody>
              <label className='form-label'>Enter The Title</label>
              <input type='text' name='title' onChange={onChange} className='form-control' placeholder='Please Enter title' />
              <label className='form-label'>Enter The Description</label>
              <input type='text' name='description' onChange={onChange} className='form-control' placeholder='Please Enter Description' />
              <label className='form-label'>Enter The Tag</label>
              <input type='text' name='tag' onChange={onChange} className='form-control' placeholder='Please Enter Tag' />
            </ModalBody>
            <ModalFooter>
              <button className='btn btn22 mt-3' onClick={handleCreateNoteSubmit}>Create Note</button><br />
            </ModalFooter>
          </form>
        </Modal>
      </div>
      {/* Cards List */}
      <div className='row'>
        {viewToggle === 'AllDetails' &&
          allnotes.map((x, index) => {
            return (
              <div className='col-md-3' key={index}>
                <div className='card'>
                  <p>{x.title}</p>
                  <p>{x.description}</p>
                  <button className='btn btn' onClick={() => handleData(x)}>View Details</button>
                </div>
              </div>
            );
          })
        }
      </div>
      {/* View Cards Details */}
      {viewToggle === 'viewDetails' &&
        <div className='row'>
          <p onClick={() => setToggle('AllDetails')}>Back</p>
          <div className='col-md-3'>
            <div className='card'>
              <p>{clickedData.title}</p>
              <p>{clickedData.description}</p>
            </div>
          </div>
        </div>
      }
      {/* Modal for additional content */}
      {modal &&
        <div className="modal" tabIndex="-1" role="dialog" style={{
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          backdropFilter: 'blur(5px)',
          zIndex: '1040',
        }}>
          <div className="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-mg">
            <div className="modal-content p-2">
              <div className="modal-body p-3 form_class">
                <div className="modal-body">
                  <div className="icon-box">
                    <i className="material-icons">&#xE5CD;</i>
                  </div>
                  <form className="row g-3" style={{
                    textAlign: 'center',
                    display: 'flex',
                    justifyContent: 'center',
                  }}>
                    <div className="row">
                      <div className="col-md-12 okkk">
                        <div className="row">
                          <div className="col-md-6">
                            {/* Additional content */}
                          </div>
                          <div className="col-md-6">
                            {/* Additional content */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  );
};

export default Home;
